#!/usr/bin/env python

from spt3g import core, dfmux, whwp
import argparse, glob
from FakeDfMuxCollator import FakeDfMuxCollator

parser = argparse.ArgumentParser()
parser.add_argument('-out', '--output_file')
parser.add_argument('-in', '--input_files', nargs='+')
parser.add_argument('-v', '--verbose', action='store_true', help='Verbose mode (print all frames)')
args = parser.parse_args()


# Begin processing
pipe = core.G3Pipeline()
#pipe.Add(core.G3Reader, filename=sorted(glob.glob(args.input_dir+'*.g3'))) # sorting is important!
pipe.Add(core.G3Reader, filename=args.input_files)

# for now for lab testing, make fixed length scans of N frames each
pipe.Add(dfmux.ScanTools.FixedLengthScans, N=1000) 

"""
# remove fake dfmux timepoint frames
def remove_fake_dfmux_frames(frame):
    if (frame.type == core.G3FrameType.Timepoint) and ('DfMux' in frame.keys()):
        return []
pipe.Add(remove_fake_dfmux_frames)
"""
# instead of removing them, use the G3Times in each to add an array to the eventual data file for sanity checks
pipe.Add(FakeDfMuxCollator)

# consolidate data from the warm half wave plate angular encoder into arrays in the scan frame
pipe.Add(whwp.WHWPCollator)

if args.verbose:
    pipe.Add(core.Dump)

# Finally, write data to disk
pipe.Add(core.G3Writer, filename=args.output_file)

pipe.Run()
