"""
Record HWP encoder data without having to have the Iceboards running
Does this by introducing fake Timepoint frames with the right key to fool the WHWP modules
"""

from spt3g import core, whwp
import time, argparse, copy, os
import numpy as np

core.set_log_level(core.G3LogLevel.LOG_NOTICE)

parser = argparse.ArgumentParser()
parser.add_argument('--time', type=int, help='Number of seconds to record for', default=180)
parser.add_argument('--output', metavar='/path/to/files/', help='Directory in which to place output files')
parser.add_argument('--max_file_size', dest='max_file_size', default=1024, help='Maximum file size in MB', type=int)
args = parser.parse_args()

# generate bolometer timepoint frames artificially
bolo_sample_rate = 152 # roughly, but not exactly
i=0
def TimedFiniteSource(frame, start_time, time_len):
    global i
    while time.time() < start_time + time_len:
        if i%(10*bolo_sample_rate)==0:
            print('{:d} seconds remaining...'.format(int(start_time + time_len - time.time())))
        frame = core.G3Frame(core.G3FrameType.Timepoint)
        time.sleep(1.0/float(bolo_sample_rate))
        frame['EventHeader'] = core.G3Time.Now()
        frame['DfMux'] = 0 # just to have something for that key in the frame
        frame['filler'] = core.G3VectorDouble(np.random.randn(100000))
        i += 1
        return [frame]
    # return an empty list once we're done so the pipeline stops
    return []

whwp_collector = whwp.WHWPCollector()

def filename(frame, seq):
    if 'EventHeader' in frame:
        t = frame['EventHeader']
    else:
        t = core.G3Time.Now()
    return os.path.join(args.output, t.GetFileFormatString() + '.g3')


# pipeline setup and execution
pipe = core.G3Pipeline()
pipe.Add(TimedFiniteSource, start_time=time.time(), time_len=args.time)

pipe.Add(whwp.WHWPBuilder, collector=whwp_collector)

pipe.Add(core.G3MultiFileWriter, filename=args.output+'file-%02u.g3', size_limit=args.max_file_size*1024*1024)
pipe.Run(profile=True)

# since the collector starts a separate process, end that nicely if need be (will be taken care of if this script is terminated
# with a SIGINT)
whwp_collector.stop()
