#!/usr/bin/env python

from spt3g import core, dfmux, calibration
import socket, os, shutil, sys, glob

core.set_log_level(core.G3LogLevel.LOG_INFO, 'G3Reader')

if len(sys.argv) != 2:
    raise RuntimeError('Need to specify input file!')
input_file = sys.argv[1]
output_file = os.path.abspath('/'.join(input_file.split('/')[:-2])) + '/scanified/' + os.path.basename(input_file)
print(input_file)
print(output_file)

verbose = True
max_file_size = 1024

# Begin processing
pipe = core.G3Pipeline()
pipe.Add(core.G3Reader, filename=input_file)

# for now for lab testing, make fixed length scans of N frames each
# hack for lab testing: make fixed length scans but super long to avoid multiple files
ten_hours = 152 * 60 * 60 * 10
pipe.Add(dfmux.ScanTools.FixedLengthScans, N=ten_hours)

# aggregate bolometer time samples into timestreams, compressing when done and removing original time samples when done
pipe.Add(dfmux.DfMuxCollator, flac_compress=False, drop_timepoints=True)

if verbose:
    pipe.Add(core.Dump)

# Finally, write data to disk
pipe.Add(core.G3Writer, filename=output_file)

pipe.Run()

