#!/usr/bin/env python

from spt3g import core, dfmux
import socket, os
import time
import pydfmux
import sys

hardware_map = '/home/jgroh/hardware_maps/berkeley/apex/run44/run44.yaml'
output_dir = '/home/jgroh/TOD/run_44/raw/'
max_file_size = 50*1024 # in MB, so this is 50 GB (huge and hopefully never attained)
verbose = False

output_filename = sys.argv[1]

print('Initializing hardware map and boards')
hwm = pydfmux.load_session(open(hardware_map, 'r'))['hardware_map']
if hwm.query(pydfmux.core.dfmux.IceCrate).count() > 0:
        hwm.query(pydfmux.core.dfmux.IceCrate).resolve()

print('Beginning data acquisition')
# Set up DfMux consumer
pipe = core.G3Pipeline()
builder = dfmux.DfMuxBuilder([int(board.serial) for board in hwm.query(pydfmux.IceBoard)])

# Get the local IP(s) to use to connect to the boards by opening test
# connections. Using a set rather than a list deduplicates the results.
local_ips = set()
for board in hwm.query(pydfmux.core.dfmux.IceBoard):
    testsock = socket.create_connection(('iceboard' + board.serial + '.local', 80))
    local_ips.add(testsock.getsockname()[0])
    testsock.close()
print('Creating listeners for %d boards on interfaces: %s' % (hwm.query(pydfmux.core.dfmux.IceBoard).count(), ', '.join(local_ips)))

# Set up listeners per network segment and point them at the event builder
collectors = [dfmux.DfMuxCollector(ip, builder) for ip in local_ips]
pipe.Add(builder)

# Catch errors if samples have become misaligned. Don't even bother processing
# data involving a significant (N-2) reduction from the boards we should have.
nboards = hwm.query(pydfmux.IceBoard).count()
n_badpkts = 0
n_goodpkts = 0
logtweaked = False
def yellanddrop(fr):
    global n_badpkts
    global n_goodpkts
    global logtweaked

    if fr.type != core.G3FrameType.Timepoint:
        return

    if len(fr['DfMux']) < nboards-2:
        if n_badpkts > 0 and n_badpkts % 100 == 0:
            core.log_error('Only %d/%d boards (%s) responding for %d samples -- check for sample misalignment. Temporarily suppressing DfMuxBuilder logging and disabling data archiving.' % (len(fr['DfMux']), nboards, ', '.join([str(k) for k in fr['DfMux'].keys()]), n_badpkts), unit='Data Acquisition')
            # Turn up the threshold on DfMuxBuilder to prevent flooding the console
            core.set_log_level(core.G3LogLevel.LOG_ERROR, 'DfMuxBuilder')
            logtweaked = True
        n_badpkts += 1
        n_goodpkts = 0
        return []
    else:
        n_goodpkts += 1
        if n_goodpkts > 5 and logtweaked:
            # Turn the threshold back down
            core.set_log_level(core.G3LogLevel.LOG_NOTICE, 'DfMuxBuilder')
            core.log_notice('Gross board misalignment resolved. Re-enabling DfMuxBuilder logging and data archiving.', unit='Data Acquisition')
            logtweaked = False
            n_badpkts = 0
pipe.Add(yellanddrop)

# Insert current hardware map into data stream. This is critical to get the
# board ID -> IP mapping needed to do anything useful with the data
pipe.Add(dfmux.PyDfMuxHardwareMapInjector, pydfmux_hwm=hwm)

# For visualization, add nominal pointing
pipe.Add(dfmux.PyDfMuxBolometerPropertiesInjector, pydfmux_hwm=hwm)

if verbose:
    pipe.Add(core.Dump)

# JCG - use local time for filenames
#def filename(frame, seq):
#    return os.path.join(output_dir, time.strftime('%Y%m%d_%H%M%S') + '.g3')
#pipe.Add(core.G3MultiFileWriter, filename=filename, size_limit=max_file_size*1024*1024)
# actually,  just use the argument
#pipe.Add(core.G3MultiFileWriter, filename=output_filename, size_limit=max_file_size*1024*1024)
pipe.Add(core.G3Writer, filename=output_filename)

for collector in collectors:
    collector.Start()
pipe.Run()
