"""
Module that adds an array of G3Times from my fake "bolometer sample" Timepoint frames for testing the HWP DAQ code
Deletes the original fake Timepoint frames in the process
"""

import numpy as np
from spt3g import core

class FakeDfMuxCollator(object):
    def __init__(self):
        self.buffer = [] # buffer of frames that will be filled during scans and emptied at a new scan start
        self.waiting = False # whether or not we're buffering frames.  Most of the time will be True

        self.dfmux_times = core.G3VectorTime()

    def DumpToScanFrame(self, ret_frames):
        # append the vectors we've been forming to the Scan frame (first item in the buffer)
        self.buffer[0]['dfmux_times'] = self.dfmux_times

        # finally return frames to the next module and clear te buffer.  This should be 1 scan's worth
        ret_frames += self.buffer
        self.buffer = []

        # even this may be set to True immediately, just in case wait for it to be set again
        self.waiting = False

        # clear the data vector
        self.dfmux_times = core.G3VectorTime()

    def __call__(self, frame):
        # frames to pass to the next module.  Should be either:
        # - just one frame in the case that we haven't hit the first Scan frame yet
        # - no frames while we're processing a whole Scan's worth
        # - a whole Scan's worth of frames once we're done with a scan
        ret_frames = []

        if frame.type == core.G3FrameType.Timepoint and 'DfMux' in frame.keys():
            # store the data
            self.dfmux_times.append(frame['EventHeader'])
            return ret_frames

        if frame.type == core.G3FrameType.EndProcessing:
            # if this is the last scan, dump to the current scan frame
            if self.waiting:
                self.DumpToScanFrame(ret_frames)
            # let the rest of the pipeline see the EndProcessing frame too
            ret_frames.append(frame)
            return ret_frames

        if frame.type == core.G3FrameType.Scan:
            # if we arrive at a scan boundary, save stuff from the previous scan
            if self.waiting:
                self.DumpToScanFrame(ret_frames)
            assert(len(self.buffer) == 0) # hopefully this is never an issue
            self.buffer.append(frame)
            self.waiting = True
            return ret_frames

        # for other kinds of frames, don't do any processing
        if self.waiting:
            self.buffer.append(frame)
        else:
            ret_frames.append(frame)
        return ret_frames
