from spt3g import core, dfmux, whwp
import os, time
import numpy as np

pipe = core.G3Pipeline()

sample_rate = 152.
i = 0
def DummyData(frame, n):
    """
    Adds a bunch of dfmux, encoder, and irig timepoint frames
    For now, just store zeroes in all the entries
    Match the types, but not necessarily the lengths, of the data we'll get
    """
    global i
    outframes = []
    while i<n:
        # dfmux frame followed by a whwp encoder frame
        dfmux = core.G3Frame(core.G3FrameType.Timepoint)
        dfmux['DfMux'] = 0 # just something to store there for now
        outframes.append(dfmux)

        # this isn't the correct number of HWP samples per bolo sample, but the point is that it's a lot
        encoder = core.G3Frame(core.G3FrameType.Timepoint)
        encoder['whwp_encoder_clk_cnts'] = core.G3VectorInt(np.zeros(1000, dtype=np.int32))
        encoder['whwp_encoder_cnts'] = core.G3VectorInt(np.zeros(1000, dtype=np.int32))
        outframes.append(encoder)

        # IRIG frames once every second
        if i % 152 == 0:
            irig = core.G3Frame(core.G3FrameType.Timepoint)
            irig['whwp_irig_start_time'] = core.G3Time.Now()
            irig['whwp_irig_start_clk_cnts'] = core.G3Int(0)
            irig['whwp_irig_synch_clk_cnts'] = core.G3VectorDouble(np.zeros(10, dtype=np.int64))
            outframes.append(irig)

        # reference pulse frames at the HWP rotation speed (2Hz)
        if i % (152/2) == 0:
            ref = core.G3Frame(core.G3FrameType.Timepoint)
            ref['whwp_encoder_cnts_at_ref'] = 0
            outframes.append(ref)

            # uncomment this if you care about the times being correct
            #time.sleep(1./sample_rate)
        i += 1
        
        return outframes
        
    return [] # after we're done, end by returning an empty list to the next module
pipe.Add(DummyData, n=10000)

# my hack on the dfmux version since we have a few kinds of timepoint frames now
class fixed_length_scans(object):
    def __init__(self, N=1000):
        self.N = N
        self.count = 0
    def __call__(self, frame):
        ret = []
        if frame.type == core.G3FrameType.Timepoint and 'DfMux' in frame.keys():
            if self.count % self.N == 0:
                ret.append(core.G3Frame(core.G3FrameType.Scan))
            self.count += 1
        ret.append(frame)
        return ret
print 'Creating scans with a fixed length of 1000'
pipe.Add(fixed_length_scans, N=1000)

# remove the dfmux frames
pipe.Add(lambda frame: not (frame.type == core.G3FrameType.Timepoint and 'DfMux' in frame.keys()))

# test the WHWP collator
pipe.Add(whwp.WHWPCollator)

def check_contents(frame):
    if frame.type == core.G3FrameType.Scan:
        print 'Length of encoder counts timestream for this scan: {:d}'.format(len(frame['whwp_encoder_cnts']))
pipe.Add(check_contents)

pipe.Add(core.G3Writer, filename='scanified.g3')
pipe.Run()
