from spt3g import core, whwp
import time, argparse, copy
import numpy as np
import matplotlib.pyplot as plt

parser = argparse.ArgumentParser()
parser.add_argument('--time', type=int, help='Number of seconds to record for', default=10)
parser.add_argument('--outfile', type=str, help='If given, save data to output file with this path', default=None)
parser.add_argument('--plot_angle', type=bool, help='Whether to plot the hwp angle as a function of time', default=False)
args = parser.parse_args()

pipe = core.G3Pipeline()

# generate bolometer timepoint frames artificially
bolo_sample_rate = 152 # roughly
i=0
def TimedFiniteSource(frame, start_time, time_len):
    global i
    while time.time() < start_time + time_len:
        if i%(10*bolo_sample_rate)==0:
            print('{:d} seconds remaining...'.format(int(time_len-(i/bolo_sample_rate))))
        frame = core.G3Frame(core.G3FrameType.Timepoint)
        time.sleep(1.0/float(bolo_sample_rate))
        frame['EventHeader'] = core.G3Time.Now()
        frame['DfMux'] = 0 # just to have something for that key in the frame
        i += 1
        return [frame]
    # return an empty list once we're done so the pipeline stops
    return []
pipe.Add(TimedFiniteSource, start_time=time.time(), time_len=args.time) # seconds

# start the collection of packets from the HWP arduino
whwp_collector = whwp.WHWPCollector()

# insert hwp data into frames in the pipeline
pipe.Add(whwp.WHWPBuilder, collector=whwp_collector)

# instead of writing to a file and then reading it, skip all that and just grab the data from one kind of frame
length_of_encoder_queue = []
encoder_cnts = []
clk_cnts = []
asdf = 0
def get_encoder_data(frame):
    global encoder_cnts
    global clk_cnts
    global asdf
    if frame.type == core.G3FrameType.Timepoint and 'whwp_encoder_cnts' in frame.keys():
        print(asdf)
        length_of_encoder_queue.append(len(frame['whwp_encoder_cnts']))
        for cnt in frame['whwp_encoder_cnts']:
            encoder_cnts.append(cnt)
        for cnt in frame['whwp_encoder_clk_cnts']:
            clk_cnts.append(cnt)
        asdf += 1
pipe.Add(get_encoder_data)

if args.outfile is not None:
    pipe.Add(core.G3Writer, filename=args.outfile)

# run the pipeline
pipe.Run(profile=True)

# end the collector nicely (separate process)
whwp_collector.stop()

if args.plot_angle:
    # check that we're able to read the angle continuously (just use arduino time for now)
    def account_for_wrapping(input_array, nbits):
        add_val = int(2.0**nbits)
        out_arr = copy.copy(input_array)
        arr = copy.copy(input_array)
        arr[0] = 1
        arr[1:] = arr[1:] - arr[:-1]
        for ind in np.where(arr < 0)[0]:
            out_arr[ind:] += add_val
        return out_arr

    def convert_to_radians(raw_counts):
        out = []
        for i in range(len(raw_counts)):
            out.append(raw_counts[i] * 2 * np.pi / 1.e5)
            if out[i] > 2*np.pi:
                out[i] = out[i] % (2*np.pi)
        return out

    try:
        encoder_cnts_monotonic = np.array(account_for_wrapping(np.array(encoder_cnts), 16))
        hwp_angle = convert_to_radians(encoder_cnts_monotonic)

        clk_cnts = np.array(account_for_wrapping(np.array(clk_cnts), 32))
        time = (clk_cnts - clk_cnts[0]) / 16.e6 # Arduino clock is nominally 16 MHz

        plt.plot(time, hwp_angle,'b.')
        plt.xlabel('Time according to the Arduino clock [s]')
        plt.ylabel('HWP angle [rad]')
        plt.show()
    except:
        print("Error plotting! Are you sure you're receiving packets?")
        
