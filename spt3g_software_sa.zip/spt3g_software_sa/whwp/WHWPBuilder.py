import numpy as np
import time
import struct
from spt3g import core

@core.indexmod
class WHWPBuilder(object):
    """
    Every time a frame associated with a bolometer sample is reached, empty the queue
    that the WHWPCollector module is populating with WHWP encoder data.  Puts these
    nicely into the pipeline
    """

    __counter_info_length = 150 # hard-coded on the Arduino, must match
    __counter_packet_size = 2 + 6 * __counter_info_length # the header is a uint16_t, each sample is 3 uint16_t's, and
                                                          # there are _counter_info_length many of them
    __irig_packet_size = 66 # the IrigInfo C struct encapsulates 1 uint16_t, 1 uint32_t, 1 uint16_t[10], and 1 uint16_t[10]
    __ref_packet_size = 8 # the RefPulseInfo C struct encapsulates 4 uint16_t variables
    __error_packet_size = 4

    
    def __init__(self, collector):
        self.queue = collector.queue
        self.__data = b''
        
    def __call__(self, frame):
        # only act when a timepoint frame from bolo samples is reached
        if (frame.type == core.G3FrameType.Timepoint) and ('DfMux' in frame.keys()):

            # frames to pass to the next module, including the current bolometer sample frame
            return_frames = [frame]

            # empty the queue and parse its contents appropriately
            approx_size = self.queue.qsize()
            for ielement in range(approx_size):
                self.__data = self.queue.get(block=True, timeout=None)

                # loop until data is empty, parsing the contents appropriately
                data_len = len(self.__data)
                parse_index = 0
                while parse_index < data_len:
                    header = self.__data[parse_index : parse_index + 2]
                    if header == b'\xaf\x1e':
                        return_frames.append(self.__process_counter_packet(parse_index))
                        parse_index += self.__counter_packet_size
                    elif header == b'\xcd\xab':
                        return_frames.append(self.__process_reference_packet(parse_index))
                        parse_index += self.__ref_packet_size
                    elif header == b'\xfe\xca':
                        return_frames.append(self.__process_irig_packet(parse_index))
                        parse_index += self.__irig_packet_size
                    elif header == b'\x2a\xe1':
                        self.__process_error_packet(parse_index)
                        parse_index += self.__error_packet_size
                    else:
                        raise RuntimeError("Bad header: {:s}".format(header.hex()))
                self.__data = b'' # probably redundant

            return return_frames

            
    def __process_counter_packet(self, parse_index):
        unpacked_data = np.array(struct.unpack('<' + 'HHH' * self.__counter_info_length,
                                               self.__data[parse_index + 2 : parse_index + self.__counter_packet_size]))
        clk_cnts = (unpacked_data[::3] << 16) + unpacked_data[1::3]
        encoder_cnts = unpacked_data[2::3].astype(np.int32)
        clk_cnts = core.G3VectorInt(clk_cnts) # note that this step casts to signed integers of the same size, so there'll be some wraparound to deal with
        encoder_cnts = core.G3VectorInt(encoder_cnts)
        
        counter_frame = core.G3Frame(core.G3FrameType.Timepoint)
        counter_frame['whwp_encoder_clk_cnts'] = clk_cnts
        counter_frame['whwp_encoder_cnts'] = encoder_cnts
        return counter_frame

    def __process_reference_packet(self, parse_index):
        unpacked_data = struct.unpack('<HHH', self.__data[parse_index + 2 : parse_index + self.__ref_packet_size])
        clk_cnts_at_ref = (unpacked_data[0] << 16) + unpacked_data[1]
        encoder_cnts_at_ref = unpacked_data[2]
        
        reference_frame = core.G3Frame(core.G3FrameType.Timepoint)
        reference_frame['whwp_clk_cnts_at_ref'] = core.G3Int(clk_cnts_at_ref)
        reference_frame['whwp_encoder_cnts_at_ref'] = core.G3Int(encoder_cnts_at_ref)
        return reference_frame
        
    def __process_irig_packet(self, parse_index):
        unpacked_data = struct.unpack('<I' + 'H'*10 + 'I'*10,
                                      self.__data[parse_index + 2 : parse_index + self.__irig_packet_size])
        start_clk_cnts = unpacked_data[0] # the arduino clock counts when the irig packet starts
        irig_bits = list(unpacked_data[1:11]) # value stored in the ith group of 10 bits (100 bits total per IRIG-B frame)
        synch_clk_cnts = unpacked_data[11:21] # the arduino clock counts at each of the P_i pulses (read the IRIG-B standard)
        
        # convert raw IRIG bits to a meaningful time
        irig_bits[0] = irig_bits[0] >> 1; # correct for the bit shift in the seconds field (1st bit is the Pr pulse)
        irig_bits = binary_coded_decimal_to_decimal(irig_bits) # convert to decimal
        year = irig_bits[5]
        yday = irig_bits[3] + (irig_bits[4] & 0x3)*100 # refer to the IRIG-B standard, sorry
        if year == 0: # Stupid IRIG generators don't always have year
            systime = time.gmtime()
            year = systime.tm_year - 2000 # Or centuries...
            # Handle New Year's: if one clock is at the end of the year
            # and the other is at the beginning, add/subtract a year
            # appropriately. This assumes the clock deltas are at most
            # a day, which seems fine.
            if systime.tm_yday <= 1 and yday >= 364:
                year -= 1
            elif systime.tm_yday >= 364 and yday <= 1:
                year += 1

        start_time = core.G3Time(y=year, d=yday, h=irig_bits[2], m=irig_bits[1], s=irig_bits[0], ss=0) # no subseconds
        start_clk_cnts = core.G3Int(start_clk_cnts) # G3Int is an int64_t under the hood, so casting a uint32_t is fine
        synch_clk_cnts = core.G3VectorDouble(list(synch_clk_cnts)) # G3VectorInt is a vector of int32_t's under the hood, so
                                                                   # use something with more bits
        
        irig_frame = core.G3Frame(core.G3FrameType.Timepoint)
        irig_frame['whwp_irig_start_time'] = start_time
        irig_frame['whwp_irig_start_clk_cnts'] = start_clk_cnts
        irig_frame['whwp_irig_synch_clk_cnts'] = synch_clk_cnts
        return irig_frame
        
    def __process_error_packet(self, parse_index):
        err_val = struct.unpack('<H', self.__data[parse_index + 2 : parse_index + self.__error_packet_size])
        raise RuntimeError("Error packet received from WHWP encoder arduino: {:s}".format(err_val))

def binary_coded_decimal_to_decimal(bytes):
    """Convert each block (calling it a byte here) of 10 bits in the IRIG-B standard to decimal"""
    outbytes = [0,]*len(bytes) # should be 10 of these, for 100 bits total
    for i in range(len(bytes)):
        b = bytes[i]
        lowb = b & 0xf # low bits are 2, 4, 8
        highb = b >> 5 # high bits are 10, 20, 40, etc
        outbytes[i] = lowb + highb*10
    return outbytes


