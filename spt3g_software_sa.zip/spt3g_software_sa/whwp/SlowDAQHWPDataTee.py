import sys, struct, socket, errno
from spt3g import core

@core.indexmod
class SlowDAQHWPDataTee(object):
    '''
    Module that serves WHWP data to the slowdaq when asked
    '''
    def __init__(self, port=50029, chunk_length_seconds=2):
        '''
        Set up the socket connection and internal data buffer
        '''
        core.log_info('Listening for requests from slowdaq on port %d' % port, unit='SlowDAQWHWPDataTee')

        self.socket = socket.socket()
        self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

        self.socket.bind(('', port))
        self.socket.listen(5)
        self.socket.setblocking(False)
        self.data = {}

        self.time_chunk = None
        self.chunk_length_seconds = int(chunk_length_seconds)
        
    def __call__(self, frame):

        # if we have a timepoint frame associated with the bolometer data, update the timer
        if frame.type == core.G3FrameType.Timepoint and 'DfMux' in frame:

            seconds = int(frame['EventHeader'].time/core.G3Units.s)
            self.time_chunk = seconds - seconds % self.chunk_length_seconds
        
        # if we have a timepoint frame associated with the hwp data, fill the buffer
        if frame.type == core.G3FrameType.Timepoint and 'DfMux' not in frame:

            # in case this is the first frame inside the current time window
            if self.time_chunk not in self.data:
                self.data[self.time_chunk] = {'encoder_cnts': [],
                                              'encoder_clk_cnts': [],
                                              'encoder_cnts_at_ref': [],
                                              'clk_cnts_at_ref': [],
                                              'irig_start_time': [],
                                              'irig_start_clk_cnts': [],
                                              'irig_synch_clk_cnts': []}

            # populate the relevant lists with whatever's in this frame
            if 'whwp_encoder_cnts' in frame.keys():
                for i in range(len(frame['whwp_encoder_cnts'])):
                    self.data[self.time_chunk]['encoder_cnts'].append(frame['whwp_encoder_cnts'][i])
                    self.data[self.time_chunk]['encoder_clk_cnts'].append(frame['whwp_encoder_clk_cnts'][i])
            elif 'whwp_clk_cnts_at_ref' in frame.keys():
                self.data[self.time_chunk]['encoder_cnts_at_ref'].append(frame['whwp_encoder_cnts_at_ref'])
                self.data[self.time_chunk]['clk_cnts_at_ref'].append(frame['whwp_clk_cnts_at_ref'])
            elif 'whwp_irig_start_time' in frame.keys():
                self.data[self.time_chunk]['irig_start_time'].append(frame['whwp_irig_start_time'])
                self.data[self.time_chunk]['irig_start_clk_cnts'].append(frame['whwp_irig_start_clk_cnts'])
                for i in range(len(frame['whwp_irig_synch_clk_cnts'])): # there should be 10 of these
                    self.data[self.time_chunk]['irig_synch_clk_cnts'].append(frame['whwp_irig_synch_clk_cnts'][i])

        # check for new connections once we have a buffer
        if len(self.data) == 2:
            keys = list(self.data.keys())
            keys.sort()
            
            try:
                s, origin_ip = self.socket.accept()
            except socket.error as e:
                if e.errno != errno.EAGAIN and e.errno != errno.EWOULDBLOCK:
                    raise
                # if no one's listening, still prune the buffer
                del self.data[keys[0]]
                return

            core.log_debug('Accepted connection from %s:%d' % origin_ip, unit='SlowDAQWHWPDataTee')
            s.setblocking(True)
            to_send = self.PackForSlowDAQ(self.data[keys[0]])
            retval = s.sendall(to_send)
            assert retval is None
            s.close()

            # prune the buffer - only keep the most recent data
            del self.data[keys[0]]

        elif len(self.data) > 2:
            raise RuntimeError('Buffer too long!')        

            
    @staticmethod
    def PackForSlowDAQ(data):
        """
        Format:
        signed 32-bit int: length of entire blob

        signed 32-bit int: number of entries in encoder_cnts
        that many signed 64-bit ints: values in encoder_cnts
        signed 32-bit int: number of entries in encoder_clk_cnts
        that many signed 64-bit ints: values in encoder_clk_cnts
        signed 32-bit int: number of entries in encoder_cnts_at_ref
        that many signed 64-bit ints: values in encoder_cnts_at_ref
        signed 32-bit int: number of entries in clk_cnts_at_ref
        that many signed 64-bit ints: values in clk_cnts_at_ref
        signed 32-bit int: number of entries in irig_start_time
        that many doubles: values in irig_start_time
        signed 32-bit int: number of entries in irig_start_clk_cnts
        that many signed 64-bit ints: values in irig_start_clk_cnts
        signed 32-bit int: number of entries in irig_synch_clk_cnts
        that many signed 64-bit ints: values in irig_synch_clk_cnts

        All values little-endian
        """
        buf = b'' # nothing here, just to have something to increment

        # encoder_cnts
        buf += struct.pack('<i', len(data['encoder_cnts']))
        for encoder_cnt in data['encoder_cnts']:
            buf += struct.pack('<q', encoder_cnt)

        # encoder_clk_cnts
        buf += struct.pack('<i', len(data['encoder_clk_cnts']))
        for encoder_clk_cnt in data['encoder_clk_cnts']:
            buf += struct.pack('<q', encoder_clk_cnt)

        # encoder_cnts_at_ref
        buf += struct.pack('<i', len(data['encoder_cnts_at_ref']))
        for encoder_cnt_at_ref in data['encoder_cnts_at_ref']:
            buf += struct.pack('<q', encoder_cnt_at_ref)

        # clk_cnts_at_ref
        buf += struct.pack('<i', len(data['clk_cnts_at_ref']))
        for clk_cnt_at_ref in data['clk_cnts_at_ref']:
            buf += struct.pack('<q', encoder_cnt_at_ref)

        # irig_start_time
        buf += struct.pack('<i', len(data['irig_start_time']))
        for t in data['irig_start_time']:
            buf += struct.pack('<d', t.mjd) # send a MJD, not the custom G3 type

        # irig_start_clk_cnts
        buf += struct.pack('<i', len(data['irig_start_clk_cnts']))
        for irig_start_clk_cnt in data['irig_start_clk_cnts']:
            buf += struct.pack('<q', irig_start_clk_cnt)
        
        # irig_synch_clk_cnts
        buf += struct.pack('<i', len(data['irig_synch_clk_cnts']))
        for irig_synch_clk_cnt in data['irig_synch_clk_cnts']:
            buf += struct.pack('<q', irig_synch_clk_cnt)

        # prepend the length to help safeguard against incomplete transmissions over the network
        buf = struct.pack('<i', sys.getsizeof(buf)) + buf
        
        return buf
    
