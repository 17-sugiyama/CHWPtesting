import multiprocessing
import socket
import errno
import ctypes
import signal
import time

class WHWPCollector(object):
    """
    In a separate process, listens for UDP packets from the WHWP Arduino and populates a queue that the WHWPBuilder object
    will read from
    """

    __read_chunk_size = 8192 # power of 2 to be more efficient
    
    def __init__(self, arduino_port = 8778):
        """
        set up the socket connection (non-blocking)
        note that sockets are automatically closed when they are garbage collected
        Arguments:
            arduino_port - port to use
        """
        self.__s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM) # use IPv4 internet protocol, datagram type
        self.__s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1) # allow reuse of addresses in the bind call below
        self.__s.setblocking(False) # this is critical.  Don't even think about touching this
        self.__s.bind(("", arduino_port))

        self.__data = b''

        # used to signal to stop recording
        self.__should_stop = multiprocessing.Value(ctypes.c_bool, False)
        self.__stopped = multiprocessing.Value(ctypes.c_bool, False)
        
        # start the relaying process
        self.queue = multiprocessing.Queue()
        self.__process = multiprocessing.Process(target=self.relay_HWP_data, args=(self.__should_stop, self.__stopped))
        self.__process.start()

        # deal with SIGINT interruptions (nominally how we stop the DAQ) nicely
        signal.signal(signal.SIGINT, self.sigint_handler_parent)
        
    def sigint_handler_parent(self, signal, frame):
        "If SIGINT is sent, nicely terminate the child listening process without corrupting the queue"
        self.stop()

    def sigint_handler_child(self, signal, frame):
        "Ignore SIGINT in the child process"
        pass

    def relay_HWP_data(self, should_stop, stopped):
        # in case the SIGINT signal is sent to this process, ignore it to avoid corrupting things
        signal.signal(signal.SIGINT, self.sigint_handler_child)

        while True:
            # check to see if we need to stop recording
            if should_stop.value:
                break
            
            # check the socket, continuing if there's nothing there yet
            try:
                self.__data += self.__s.recv(self.__read_chunk_size)
            except socket.error as err:
                if err.errno != errno.EAGAIN: # in the case of a real problem, re-raise the exception
                    raise
                else: # otherwise if it's just empty, continue with the program execution
                    pass

            # push the data to the queue
            if len(self.__data) > 0:
                self.queue.put(obj=self.__data, block=True, timeout=None)
                self.__data = b''

        # let the parent process know that it's now safe to terminate this child process
        with stopped.get_lock():
            stopped.value = True

            
    def stop(self):
        "Stops the listening process that's grabbing packets from the Arduino"
        # signal to the child process that it should finish up and end
        with self.__should_stop.get_lock():
            self.__should_stop.value = True

        # wait until the process is in a safe state, then terminate it
        while not self.__stopped.value:
            time.sleep(0.001)
        self.__process.terminate()

        # block until the child process really is dead
        self.__process.join()
        
