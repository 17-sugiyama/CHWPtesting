"""
Module that moves Timepoint frames with HWP data into single G3Timestreams in Scan frames

This could probably afford to be cleaned up a bit
"""

import numpy as np
from spt3g import core

# For python2-3 compatiblity
import sys
if sys.version_info.major > 2:
    xrange = range

@core.indexmod
class WHWPCollator(object):
    '''
    Move WHWP data to Scan frames, optionally deleting the original Timepoint frames where that data lives
    '''
    def __init__(self, drop_timepoints = True):
        self.drop_timepoints = drop_timepoints
        self.buffer = [] # buffer of frames that will be filled during scans and emptied at a new scan start
        self.waiting = False # whether or not we're buffering frames.  Most of the time will be True

        # dictionaries of vectors that will hold hwp data
        self.encoder_cnts = core.G3VectorInt()
        self.clk_cnts = core.G3VectorInt()
        self.encoder_cnts_at_ref = core.G3VectorInt()
        self.clk_cnts_at_ref = core.G3VectorInt()
        self.irig_start_time = core.G3VectorTime()

        # even though the clocks are 16 bits, to account for overflow in the arduino software we have 32-bit numbers running around
        # while the G3Int type is an int64_t under the hood, annoyingly the G3VectorInt type is only a vector of int32_t's under the hood
        # so use a vector of doubles to avoid overflow
        self.irig_start_clk_cnts = core.G3VectorDouble()
        self.irig_synch_clk_cnts = core.G3VectorDouble()
        
    def DumpToScanFrame(self, ret_frames):
        # append the vectors we've been forming to the Scan frame (first item in the buffer)
        self.buffer[0]['whwp_encoder_cnts'] = self.encoder_cnts
        self.buffer[0]['whwp_clk_cnts'] = self.clk_cnts
        self.buffer[0]['whwp_encoder_cnts_at_ref'] = self.encoder_cnts_at_ref
        self.buffer[0]['whwp_clk_cnts_at_ref'] = self.clk_cnts_at_ref
        self.buffer[0]['whwp_irig_start_time'] = self.irig_start_time
        self.buffer[0]['whwp_irig_start_clk_cnts'] = self.irig_start_clk_cnts
        self.buffer[0]['whwp_irig_synch_clk_cnts'] = self.irig_synch_clk_cnts

        # finally return frames to the next module and clear the buffer.  This should be 1 scan's worth
        ret_frames += self.buffer
        self.buffer = []
        
        # even though this may be set to True immediately, just in case wait for it to be set again
        self.waiting = False
        
        # clear data from the hwp data lists
        # CAREFUL: this relies on the python garbage collector not being too awful
        self.encoder_cnts = core.G3VectorInt()
        self.clk_cnts = core.G3VectorInt()
        self.encoder_cnts_at_ref = core.G3VectorInt()
        self.clk_cnts_at_ref = core.G3VectorInt()
        self.irig_start_time = core.G3VectorTime()
        self.irig_start_clk_cnts = core.G3VectorDouble()
        self.irig_synch_clk_cnts = core.G3VectorDouble()
        
        
    def __call__(self, frame):
        # frames to pass to the next module.  Should be either:
        # - just one frame in the case that we haven't hit the first Scan frame yet
        # - no frames while we're processing a whole Scan's worth
        # - a whole Scan's worth of frames once we're done with a scan
        ret_frames = []
        
        if frame.type == core.G3FrameType.Timepoint:        

            if 'whwp_encoder_cnts' in frame.keys():
                # store the data
                for i in xrange(len(frame['whwp_encoder_cnts'])):
                    self.encoder_cnts.append(frame['whwp_encoder_cnts'][i]) # append calls to G3Vectors may be expensive....
                    self.clk_cnts.append(frame['whwp_encoder_clk_cnts'][i]) # append calls to G3Vectors may be expensive....

                # drop the original frames if requested
                if not self.drop_timepoints:
                    ret_frames.append(frame)
                    
                return ret_frames
            
            elif 'whwp_clk_cnts_at_ref' in frame.keys():
                # store the data
                # satoru's workaround to convert to int32. (Possibly, fixing this in WHWPBuilder would be nicer...)
                self.encoder_cnts_at_ref.append(int(np.int32(frame['whwp_encoder_cnts_at_ref']))) 
                self.clk_cnts_at_ref.append(int(np.int32(frame['whwp_clk_cnts_at_ref'])))
                
                # drop the original frames if requested
                if not self.drop_timepoints:
                    ret_frames.append(frame)
                    
                return ret_frames
                
            elif 'whwp_irig_start_time' in frame.keys():
                # store the data
                self.irig_start_time.append(frame['whwp_irig_start_time'])
                self.irig_start_clk_cnts.append(frame['whwp_irig_start_clk_cnts'])
                for i in xrange(len(frame['whwp_irig_synch_clk_cnts'])): # there should be 10 of these
                    self.irig_synch_clk_cnts.append(frame['whwp_irig_synch_clk_cnts'][i])
                
                # drop the original frames if requested
                if not self.drop_timepoints:
                    ret_frames.append(frame)

                return ret_frames
                
        if frame.type == core.G3FrameType.EndProcessing:
            # if this is the last scan, dump to the current scan frame
            if self.waiting:
                self.DumpToScanFrame(ret_frames)
            # let the rest of the pipeline see the EndProcessing frame too
            ret_frames.append(frame)
            return ret_frames

        if frame.type == core.G3FrameType.Scan:
            # if we arrive at a scan boundary, save stuff from the previous scan
            if self.waiting:
                self.DumpToScanFrame(ret_frames)
            assert(len(self.buffer) == 0) # hopefully this is never an issue
            self.buffer.append(frame) # now start the current scan
            self.waiting = True
            return ret_frames
                
        # don't do any processing on other kinds of frames
        if self.waiting:
            self.buffer.append(frame)    
        else:
            ret_frames.append(frame)
        return ret_frames

                
