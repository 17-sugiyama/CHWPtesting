#!/usr/bin/env python

from spt3g import core, dfmux, std_processing, whwp, gcp
import socket, argparse, os, shutil

core.set_log_level(core.G3LogLevel.LOG_INFO, 'G3Reader')

parser = argparse.ArgumentParser(description='Merge GCP data with raw bolometer data, convert to scans, and compress')
parser.add_argument('output_file', metavar='/path/to/output/output_file.g3', help='File name to write output to.')
parser.add_argument('input', metavar='input', nargs='+', help='Input files to read')
parser.add_argument('gcparchives', metavar='gcparchives', help='Path to directory with GCP archive files')
parser.add_argument('-v', '--verbose', action='store_true', help='Verbose mode (print all frames)')
parser.add_argument('--max-file-size', default=1024, help='Maximum file size in MB (default 1024)')
args = parser.parse_args()

# Begin processing
pipe = core.G3Pipeline()
pipe.Add(core.G3Reader, filename=args.input)

# Decode GCP data
pipe.Add(std_processing.ARCInterposer, basedir=args.gcparchives)
pipe.Add(gcp.ARCExtract)

# Drop pointless duplicate metadata
pipe.Add(core.DeduplicateMetadata)

# for now for lab testing, make fixed length scans of N frames each
#pipe.Add(dfmux.ScanTools.FixedLengthScans, N=1000) 
# Build to scans
pipe.Add(std_processing.BuildScanFramesFromRawData, flac_compress=True, 
         max_scan_length=10000)

# consolidate data from the warm half wave plate angular encoder into arrays in the scan frame
pipe.Add(whwp.WHWPCollator)

if args.verbose:
    pipe.Add(core.Dump)

# Finally, write data to disk
pipe.Add(core.G3MultiFileWriter, filename=args.output_file,
  size_limit=args.max_file_size*1024*1024)

pipe.Run()
