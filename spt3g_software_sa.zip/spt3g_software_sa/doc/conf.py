project = "SPT3G Software"
master_doc = "index"
html_theme = "nature"
