from spt3g import core, gcp
import os, math

def ARCForTime(t, basedir):
    if isinstance(t, core.G3Time):
        t = t.GetFileFormatString()
    elif isinstance(t, str):
        t = core.G3Time(t)
        t = t.GetFileFormatString()
    
    dirs = os.listdir(basedir)
    if 'this_is_an_arcfile_summary_dir' in dirs:
        t_dayonly = t.split('_')
        t_dayonly[1] = '000000'
        t_dayonly = '_'.join(t_dayonly)
        if t_dayonly in dirs:
            dirs.sort()
            dir = os.path.join(basedir, dirs[dirs.index(t_dayonly) - 2])
        else:
            dirs.append(t)
            dirs.remove('this_is_an_arcfile_summary_dir')
            dirs.sort()
            dir = os.path.join(basedir, dirs[dirs.index(t) - 1])
    else:
        dir = basedir

    files = os.listdir(dir)
    files = [f for f in files if f.endswith('.dat') or f.endswith('.dat.gz')]
    if len(files) == 0:
        raise FileNotFoundError('No ARC files in %s' % dir)
    if t + '.dat' in files:
        return os.path.join(dir, t + '.dat')
    elif t + '.dat.gz' in files:
        return os.path.join(dir, t + '.dat.gz')
    else:
        files.append(t + '.dat')
        files.sort()
        arcindex = files.index(t + '.dat') - 1
        if arcindex == -1: arcindex = 1
        return os.path.join(dir, files[arcindex])

def NextARCFile(path):
    '''
    Path corresponding to the ARC file following this one in time.
    '''
    arcdir = os.path.dirname(path)
    arcfiles = os.listdir(arcdir)
    arcfiles.sort()
    arcfiles = [f for f in arcfiles if f.endswith('.dat') or f.endswith('.dat.gz')]
    i = arcfiles.index(os.path.basename(path))
    if i+1 < len(arcfiles):
        return os.path.join(arcdir, arcfiles[i+1])
    else:
        arcparentdir = os.path.dirname(arcdir)
        dirs = os.listdir(arcparentdir)
        if 'this_is_an_arcfile_summary_dir' in dirs:
            dirs.remove('this_is_an_arcfile_summary_dir')
        else:
            #core.log_fatal('No more data in ARC directory.', unit='ARCTimerangeReader')
            core.log_info('No more data in ARC directory.', unit='ARCTimerageReader')
            return 
        dirs.sort()
        i = dirs.index(os.path.basename(arcdir))
        if i+1 >= len(arcfiles):
            core.log_fatal('No more data in ARC directory.', unit='ARCTimerangeReader')
        arcdir = os.path.join(arcparentdir, dirs[i+1])
        arcfiles = os.listdir(arcdir)
        arcfiles.sort()
        try:
            # Some dirs have duplicates. Who knows why?
            i = arcfiles.index(os.path.basename(path)) + 1
        except (IndexError, ValueError):
            i = 0
        return os.path.join(arcdir, arcfiles[i])

@core.indexmod
class ARCTimerangeReader(object):
    '''
    Read data from an ARC directory between a given start and stop time.
    '''
    def __init__(self, start_time, stop_time, basedir='/data/sptdat/arcfile_directory'):
        self.cur_file = ARCForTime(start_time, basedir)
        core.log_info('Opening %s' % self.cur_file, unit='ARCTimerangeReader')
        self.reader = gcp.ARCFileReader(filename=self.cur_file, experiment=gcp.Experiment.PB) # PB-specific
        if isinstance(stop_time, str):
            self.stop_time = core.G3Time(stop_time)
        else:
            self.stop_time = stop_time
        if isinstance(start_time, str):
            self.start_time = core.G3Time(start_time)
        else:
            self.start_time = start_time
    def __call__(self, frame):
        t = core.G3Time(0) # 1970 predates SPT
        assert(frame is None)
        while t < self.start_time:
            nextframes = self.reader(None)
            if len(nextframes) == 0:
                self.cur_file = NextARCFile(self.cur_file)
                core.log_info('Opening %s' % self.cur_file, unit='ARCTimerangeReader')
                self.reader = gcp.ARCFileReader(filename=self.cur_file, experiment=gcp.Experiment.PB) # PB-specific
                continue
    
            assert(len(nextframes) == 1)
            t = nextframes[0]['array']['frame']['utc']
        if t > self.stop_time:
            return []
        else:
            return nextframes

@core.indexmod
class ARCInterposer(object):
    '''
    Read data from an ARC directory to provide metadata for an existing set
    of time point frames. GcpSlow frames from the ARC files will be
    interleaved with the timepoint frames in the original stream. Any
    non-timepoint frames (wiring frames, for example) will be passed through
    silently to the next module.
    '''
    def __init__(self, basedir='/data/sptdat/arcfile_directory'):
        self.basedir = basedir
        self.cur_file = None
        self.reader = None
        self.gcp_time = core.G3Time(0) # 1970 predates SPT
    def __call__(self, frame):
        if frame.type != core.G3FrameType.Timepoint or not 'EventHeader' in frame:
            return [frame]

        t = frame['EventHeader']
        if math.floor(self.gcp_time.time / core.G3Units.s) == math.floor(t.time / core.G3Units.s): # GCP slow frames are 1 second long at second boundaries
            return [frame]
        if math.floor(self.gcp_time.time / core.G3Units.s) == math.floor(t.time / core.G3Units.s) + 1: # PB-specific. PB-GCP frame is a little longer than 1 sec.
            return [frame]

        # Check that the while loop below will actually execute at least once
        if math.floor(self.gcp_time.time / core.G3Units.s) > math.floor(t.time / core.G3Units.s): 
            #core.log_fatal('Time has gone backwards: %s > %s' % (self.gcp_time, t), unit='ARCInterposer')
            core.log_info('GCP time is newer than bolo time: %s > %s' % (self.gcp_time, t), unit='ARCInterposer')
            # Try to save data even when something weird is happening...
            return [frame]

        # Loop through the file and find the GCP frame for the second including this sample
        while math.floor(self.gcp_time.time / core.G3Units.s) < math.floor(t.time / core.G3Units.s):
            if self.reader is None:
                new_file = ARCForTime(t, self.basedir)
                if self.cur_file == new_file:
                    # Correct for roundoff; avoid loops
                    new_file = NextARCFile(new_file)
                    if new_file is None: return []
                self.cur_file = new_file
                core.log_info('Opening %s for data at %s' % (self.cur_file, t), unit='ARCTimerangeReader')
                self.reader = gcp.ARCFileReader(filename=self.cur_file, experiment=gcp.Experiment.PB) # PB-specific
            nextframes = self.reader(None)
            if len(nextframes) == 0:
                self.reader = None
                continue # This will trigger the code above
    
            assert(len(nextframes) == 1)
            # The "array time" in GCP frames is the time at which
            # the frame *ends*, not when it starts, so subtract
            # one second
            # 2019/05/17: Changed to use antenna time not to be
            # affected by the system time offset
            self.gcp_time = core.G3Time(nextframes[0]['antenna0']['tracker']['utc'][0][0].time)

        return [nextframes[0], frame]


