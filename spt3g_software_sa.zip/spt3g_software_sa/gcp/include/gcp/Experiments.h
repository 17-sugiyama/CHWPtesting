#ifndef _EXPERIMENTS_H
#define _EXPERIMENTS_H

enum class Experiment {
	SPT = 0,
	PB = 1,
	BK = 2,
};

#endif
