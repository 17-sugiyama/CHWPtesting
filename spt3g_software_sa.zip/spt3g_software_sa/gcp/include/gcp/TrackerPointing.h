#ifndef TRACKERPOINTING_H
#define TRACKERPOINTING_H

#include <G3Frame.h>
#include <G3Timestream.h>
#include <string>

/*
 * Class containing Tracker pointing information from GCP
 */
class TrackerPointing : public G3FrameObject
{
public:
	TrackerPointing() : G3FrameObject() {}
	std::string Description() const;

	// Concatenate two sets of arrays together
	TrackerPointing operator + (const TrackerPointing &) const;
	TrackerPointing &operator += (const TrackerPointing &);

	//Define slow register int vectors.
	std::vector<G3Time> time;
	std::vector<int32_t> features;
	std::vector<int32_t> record;

	//Define fast-register double vectors.
	std::vector<double> horiz_mount_x, horiz_mount_y;
	std::vector<double> horiz_off_x, horiz_off_y;
	std::vector<double> encoder_off_x, encoder_off_y;

	//Define stored refraction corrections
	std::vector<double> refraction;

	// Define timing card related registers
	int timing_locked, timing_timeOffset, timing_freqOffset;
	int timing_spurious_interrupts, timing_missed_interrupts;
	
	template <class A> void serialize(A &ar, unsigned v);
};

G3_POINTERS(TrackerPointing);
G3_SERIALIZABLE(TrackerPointing, 2);

#endif

