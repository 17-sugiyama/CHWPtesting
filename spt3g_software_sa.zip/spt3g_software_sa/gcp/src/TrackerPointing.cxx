#include <pybindings.h>
#include <serialization.h>
#include <gcp/TrackerPointing.h>

template <class A> void TrackerPointing::serialize(A &ar, unsigned v)
{
	using namespace cereal;

	G3_CHECK_VERSION(v);

	// These correspond to GCP slow registers (sampled once per frame).
	ar & make_nvp("G3FrameObject", base_class<G3FrameObject>(this));
	ar & make_nvp("time", time);
	ar & make_nvp("features", features);
	ar & make_nvp("record", record);
	
	//Breaking horiz and encoder into its constituent components.
	ar & make_nvp("encoder_off_x", encoder_off_x);
	ar & make_nvp("encoder_off_y", encoder_off_y);
	ar & make_nvp("horiz_mount_x", horiz_mount_x);
	ar & make_nvp("horiz_mount_y", horiz_mount_y);
	ar & make_nvp("horiz_off_x", horiz_off_x);
	ar & make_nvp("horiz_off_y", horiz_off_y);

	if (v < 2) {
		//Old versions recorded online pointing model parameters here
		std::vector<double> junk;
		ar & make_nvp("tilts", junk);
		ar & make_nvp("flexure", junk);
		ar & make_nvp("fixedCollimation", junk);
	}

	//Online refraction corrections
	ar & make_nvp("refraction", refraction);

	ar & make_nvp("timing_locked", timing_locked);
	ar & make_nvp("timing_timeOffset", timing_timeOffset);
	ar & make_nvp("timing_freqOffset", timing_freqOffset);
	ar & make_nvp("timing_spurious_interrupts", timing_spurious_interrupts);
	ar & make_nvp("timing_missed_interrupts", timing_missed_interrupts);
}

TrackerPointing TrackerPointing::operator +(const TrackerPointing &a) const
{
	TrackerPointing t(*this);

	t += a;
	return t;
}

TrackerPointing &TrackerPointing::operator +=(const TrackerPointing &a)
{
	#define tracker_appendarr(x) x.insert(x.end(), a.x.begin(), a.x.end())

        tracker_appendarr(time);
	tracker_appendarr(features);
	tracker_appendarr(record);
	tracker_appendarr(encoder_off_x);
	tracker_appendarr(encoder_off_y);
	tracker_appendarr(horiz_mount_x);
	tracker_appendarr(horiz_mount_y);
	tracker_appendarr(horiz_off_x);
	tracker_appendarr(horiz_off_y);
	tracker_appendarr(refraction);

	#undef tracker_appendarr

	return *this;
}

std::string TrackerPointing::Description() const
{
	std::ostringstream s;

	s << time.size() << " tracker pointing samples";

	if (time.size() > 0)
		s << " from " << time[0] << " to " << time[time.size() - 1];

	return s.str();
}

G3_SERIALIZABLE_CODE(TrackerPointing);

PYBINDINGS("gcp") {
	using namespace boost::python;

	EXPORT_FRAMEOBJECT(TrackerPointing, init<>(), "GCP Tracker Pointing")
	    .def_readwrite("time", &TrackerPointing::time)
	    .def_readwrite("features", &TrackerPointing::features)
	    .def_readwrite("record", &TrackerPointing::record)
	    .def_readwrite("encoder_off_x", &TrackerPointing::encoder_off_x)
	    .def_readwrite("encoder_off_y", &TrackerPointing::encoder_off_y)
	    .def_readwrite("horiz_mount_x", &TrackerPointing::horiz_mount_x)
	    .def_readwrite("horiz_mount_y", &TrackerPointing::horiz_mount_y)
	    .def_readwrite("horiz_off_x", &TrackerPointing::horiz_off_x)
	    .def_readwrite("horiz_off_y", &TrackerPointing::horiz_off_y)
	    .def_readwrite("refraction", &TrackerPointing::refraction)
	    .def_readwrite("timing_locked", &TrackerPointing::timing_locked)
	    .def_readwrite("timing_timeOffset", &TrackerPointing::timing_timeOffset)
	    .def_readwrite("timing_freqOffset", &TrackerPointing::timing_freqOffset)
  	    .def_readwrite("timing_spurious_interrupts", &TrackerPointing::timing_spurious_interrupts)
  	    .def_readwrite("timing_missed_interrupts", &TrackerPointing::timing_missed_interrupts)
	    .def(self + self)
	    .def(self += self)
	;
}

