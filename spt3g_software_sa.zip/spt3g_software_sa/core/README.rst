----
core
----

The core directory includes infrastructural components of the software: file IO, python bindings, basic containers for plain data, the definition of G3Pipeline, etc.

