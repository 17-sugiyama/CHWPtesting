#!/usr/bin/env python

from spt3g import core, dfmux, gcp, whwp
import socket, argparse, os
from urllib.request import urlopen # python3 only
import json

parser = argparse.ArgumentParser(description='Record dfmux data to disk')
parser.add_argument('hardware_map', metavar='/path/to/hwm.yaml', help='Path to hardware map YAML file')
parser.add_argument('output', metavar='/path/to/files/', help='Directory in which to place output files')

parser.add_argument('-v', dest='verbose', action='store_true', help='Verbose mode (print all frames)')
parser.add_argument('--max-file-size', default=1024, help='Maximum file size in MB (default 1024)')
args = parser.parse_args()

# iceboard serials as of April 18th, 2019
all_boards = ['0157',
              '0081',
              '0160',
              '0060',
              '0091',
              '0098',
              '0085',
              '0086',
              '0155',
              '0154',
              '0109',
              '0103',
              '0130',
              '0102',
              '0346',
              '0145',
              '0158',
              '0107',
              '0127',
              '0075',
              '0079',
              '0124',
              '0076',
              '0330',
              '0083',
              '0082',
              '0084',
              '0128']
# get which ones are alive (require that mezzanines are powered)
boards = []
for board in all_boards:
    try:
        mezz_on = json.loads(urlopen('http://iceboard{:s}.local/tuber'.format(board),
                                     b'{"object":"Dfmux", "method":"get_mezzanine_power", "args":[1]}').readline())['result']
        if mezz_on:
            if args.verbose:
                print('Adding icieboard {:s}'.format(board))
            boards.append(board)
        else:
            print('Iceboard {:s} found to have its mezzanines not powered - skipping for DAQ since it probably crashed'.format(board))
    except:
        print('Iceboard {:s} not responding to webpage queries - skipping for DAQ since it probably crashed'.format(board))

# Tee log messages to both log file and GCP socket
console_logger = core.G3PrintfLogger()
console_logger.timestamps = True # Make sure to get timestamps in the logs
core.G3Logger.global_logger = core.G3MultiLogger([console_logger, gcp.GCPLogger()])

args.hardware_map = os.path.realpath(args.hardware_map)

# Otherwise assume the input is a list of board serials
core.log_notice('Acquiring hardware map information from boards',
                unit='Data Acquisition')
hwm = None

core.log_notice('Beginning data acquisition', unit='Data Acquisition')
# Set up DfMux consumer
pipe = core.G3Pipeline()
builder = dfmux.DfMuxBuilder([int(board) for board in boards])

# Get the local IP(s) to use to connect to the boards by opening test
# connections. Using a set rather than a list deduplicates the results.
local_ips = {}
for board in boards:
    testsock = socket.create_connection(('iceboard' + board + '.local', 80))
    local_ip = testsock.getsockname()[0]
    if local_ip not in local_ips:
        local_ips[local_ip] = set()
    local_ips[local_ip].add(int(board))
    testsock.close()
core.log_notice('Creating listeners for %d boards on interfaces: %s' %
                (len(boards), ', '.join(local_ips.keys())),
                unit='Data Acquisition')

# Set up listeners per network segment and point them at the event builder
collectors = [dfmux.DfMuxCollector(ip, builder, list(local_boards))
              for ip, local_boards in local_ips.items()]
pipe.Add(builder)

# Catch errors if samples have become misaligned. Don't even bother processing
# data involving a significant (N-2) reduction from the boards we should have.
nboards = len(boards)
n_badpkts = 0
n_goodpkts = 0
logtweaked = False
def yellanddrop(fr):
    global n_badpkts
    global n_goodpkts
    global logtweaked

    if fr.type != core.G3FrameType.Timepoint:
        return

    if len(fr['DfMux']) < nboards-2:
        if n_badpkts > 0 and n_badpkts % 100 == 0:
            core.log_error('Only %d/%d boards (%s) responding for %d samples -- check for sample misalignment. Temporarily suppressing DfMuxBuilder logging and disabling data archiving.' % (len(fr['DfMux']), nboards, ', '.join([str(k) for k in fr['DfMux'].keys()]), n_badpkts), unit='Data Acquisition')
            # Turn up the threshold on DfMuxBuilder to prevent flooding the console
            core.set_log_level(core.G3LogLevel.LOG_ERROR, 'DfMuxBuilder')
            logtweaked = True
        n_badpkts += 1
        n_goodpkts = 0
        return []
    else:
        n_goodpkts += 1
        if n_goodpkts > 5 and logtweaked:
            # Turn the threshold back down
            core.set_log_level(core.G3LogLevel.LOG_NOTICE, 'DfMuxBuilder')
            core.log_notice('Gross board misalignment resolved. Re-enabling DfMuxBuilder logging and data archiving.', unit='Data Acquisition')
            logtweaked = False
            n_badpkts = 0
pipe.Add(yellanddrop)

# Collect housekeeping when GCP asks for it and send it back to GCP when desired
pipe.Add(gcp.GCPSignalledHousekeeping)
pipe.Add(dfmux.HousekeepingConsumer)
pipe.Add(gcp.GCPHousekeepingTee)

# For visualization, add nominal pointing
# Get the bolometer properties map from disk (written separately by pydfmux)
# whenever a new wiring frame is received.
def BolometerPropertiesInjector(frame):
    if frame.type == core.G3FrameType.Wiring:
        nchan = len(frame['WiringMap'].keys())
        core.log_notice("Collecting data from %d mapped channels." % (nchan),
                        unit='Data Acquisition')
        bpm = os.path.join(os.path.dirname(args.hardware_map), 'nominal_online_cal.g3')
        try:
            if not os.path.exists(bpm):
                raise IOError('Missing file %s' % bpm)
            fr = list(core.G3File(bpm))[0]
            return [frame, fr]
        except Exception as e:
            core.log_warn('Error loading BolometerPropertiesMap: %s' % (str(e)),
                          unit='Data Acquisition')
pipe.Add(BolometerPropertiesInjector)

# Provide a tee for realtime visualization before possible buffering
# in the calibrator DAQ code
pipe.Add(core.G3ThrottledNetworkSender, hostname='*', port=5451, max_queue_size=1000)

# collect data from the warm half wave plate angular encoder
whwp_collector = whwp.WHWPCollector()
pipe.Add(whwp.WHWPBuilder, collector=whwp_collector)

# Provide a tee for monitoring that the PB2a HWP DAQ system is working
pipe.Add(whwp.SlowDAQHWPDataTee)

if args.verbose:
    pipe.Add(core.Dump)

# Provide a tee for other software to collect frames
pipe.Add(core.G3NetworkSender, hostname='*', port=5353, max_queue_size=1000)

def filename(frame, seq):
    if 'EventHeader' in frame:
        t = frame['EventHeader']
    else:
        t = core.G3Time.Now()
    return os.path.join(args.output, t.GetFileFormatString() + '.g3')
pipe.Add(core.G3MultiFileWriter, filename=filename, size_limit=args.max_file_size*1024*1024)

for collector in collectors:
    collector.Start()
pipe.Run(profile=True)

# Shut everything down
for collector in collectors:
    collector.Stop()

# If we've gotten here (normally things are terminated with a SIGINT), then end the separate WHWPCollector process nicely
whwp_collector.stop()

# C++ global destructor runs after python has closed, sometimes
# Setting the logger to None like this explicitly avoids segfaults
core.G3Logger.global_logger = None
