#!/bin/sh
#Try to leave the screen session; sometimes this ends the child processes but not reliably
echo "Commanding screen session to end."
screen -X -S datarelay quit
sleep 2
echo "Sending SIGKILL to any remaining recording processes."
pkill --signal 9 -f datarelay_pb2amonitor.py
pkill --signal 9 -f start_datarelay_pb2amonitor.sh

echo 'Stoppped the processes. Done'
