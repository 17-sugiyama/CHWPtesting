#!/bin/bash
searchstring="datarelay_pb2amonitor.py"
if ((`ps ax | grep "$searchstring" | wc -l` > 1)); then
    echo true
    exit 1
else
    echo false
    exit 0
fi
