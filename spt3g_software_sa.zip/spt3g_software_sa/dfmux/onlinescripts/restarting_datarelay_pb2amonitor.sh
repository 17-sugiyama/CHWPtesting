#!/bin/bash
echo "Attempting to stop screen session datarelay."
/home/polarbear/spt3g_software_sa/dfmux/onlinescripts/stop_datarelay_pb2amonitor.sh
sleep 1
is_running=`/home/polarbear/spt3g_software_sa/dfmux/onlinescripts/is_datarelay_running.sh`
if $is_running; then
    echo "Despite attempt to stop the screen session, the datarelay still appears to be running. NOT restarting."
    exit 1
else
    echo "No datarelay script appears to be running, launching a new bolodaq."
    /home/polarbear/spt3g_software_sa/dfmux/onlinescripts/start_screen_datarelay.sh
fi
