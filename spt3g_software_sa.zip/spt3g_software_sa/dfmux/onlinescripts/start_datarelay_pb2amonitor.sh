#!/bin/bash

# Temporary way to run the boloemter DAQ for PB2a
# Note: does NOT use the HWP for now
# TODO: figure out why sometimes there are missing samples
#
# Usage:
# ./start_daq_pb2a.sh /path/to/hardware/map.yaml /directory/where/you/want/the/data/to/go/
#
# NOTE: sending SIGINT does not appear to be enough to stop this.  In my testing I've had to find the PID then send SIGKILL

# use the clustertools software stack
eval `/home/polarbear/clustertools/py3-v2/setup.sh`

# run the daq script with the correct spt3g_software_.. environment
# take the output directory as an argument
/home/polarbear/spt3g_software_sa/build_py3-v2/env-shell.sh python /home/polarbear/spt3g_software_sa/dfmux/onlinescripts/datarelay_pb2amonitor.py $1
