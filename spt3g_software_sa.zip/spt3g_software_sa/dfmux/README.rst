-----
dfmux
-----

dfmux contains code and dataclasses to collect and store data from the DfMux system, particulary focusing on the ICE system used for SPT3G and PB2. A general overview of how the modules here interact can be found in the :doc:`dataacquisition` section of the manual.

